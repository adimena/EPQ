from sys import argv

script, filename = argv # use argv to get a filename

txt = open(filename) # opens file

print(f"Here's your file {filename}:")
print(txt.read()) # gives the file a command ("read") using dot
print(close_txt())

print("Type the filename again:")
file_again = input("> ")

txt_again = open(file_again)

print(txt_again.read())
