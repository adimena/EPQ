age = input("How old are you? ")
# "age" means what is typed in (input) of "how old are you?"
height = input("How tall are you? ")
weight = input("How much do you weigh? ")

print(f"So, you're {age} years old, {height} tall and {weight} heavy.")
