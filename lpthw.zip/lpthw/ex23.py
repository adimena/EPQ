import sys
script, encoding, error = sys.argv


def main(language_file, encoding, errors):
    line = language_file.readline() # reads one line from the given file
    
    if line: # tests whether the line has something in it
        print_line(line, encoding, errors) # see 13-18
        return main (language_file, encoding, errors) # jumps back to the top


def print_line(line, encoding, errors): # this function does the encoding
    next_lang = line.strip() # .strip() removes white spaces at the beginning and end
    raw_bytes = next_lang.encode(encoding, errors=errors) # .encode() makes a string into bytes; inside brackets tells it encoding I want and how to handle errors
    cooked_string = raw_bytes.decode(encoding, errors=errors) # .decode() makes raw bytes into a string
    
    print(raw_bytes, "<===>", cooked_string)
# Decode Bytes, Encode Strings (DBES)

languages = open("languages.txt", encoding="utf-8") # opens languages.txt file

main(languages, encoding, error)
