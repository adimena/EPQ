backslash = "hello \\ world"
single_quotes = "hello \'world\'" # we'll see if these quotes work?
double_quotes = "hello \"world\""
ascii_bell = "hello \a world"
ascii_backspace = "hello \b world"
ascii_formfeed = "hello \f world"
ascii_linefeed = "hello \n world"
character_named_name = "hello \N{name} world" # why yellow not red?
carriage_return = "hello \r world"
horizontal_tab = "hello \t world"
16-bit_hex_character = "hello \uxxxx world" # why yellow not red?
32-bit_hex_character = "hello \Uxxxxxxxx world" # why yellow not red?
ascii_vertical_tab = "hello \v world"
ooo_octal_character = "hello \ooo world" # why yellow not red?
hh_hex_character = "hellow \xhh world" # why yellow not red

print(backslash)
print(single_quotes)
print(double_quotes)
print(ascii_bell)
print(ascii_backspace)
print(ascii_formfeed)
print(ascii_linefeed)
#print(character_named_name)
print(carriage_return)
print(horizontal_tab)
#print(16-bit_hex_character)
#print(32-bit_hex_character)
print(ascii_vertical_tab)
#print(ooo_octal_character)
#print(hh_hex_character)
