name = input("What's your name? ")

print(f"Nice to meet you, {name}")
