from sys import argv
script, user_name = argv

hand = ['lamp', 'sword']

class always_possible:
    def __init__(self, input):
        self.input = input
    
    

 
class BaseInputs:
 
    def __init__(self):
        self.exit_strings = ["leave", "exit", "bye"]
        
    def inputer(self, text):
        user_input = input(">")
        if self.exit_strings in user_input:
            start()
        return user_input
        
class DoorInput(BaseInputs):

    def inputer(self, text):
        user_input = super().inputer(self.exit_strings)
        if "slam" in user_input:
            print("slamming door")
            
door_input = DoorInput()
door_input.inputer("slam door")




def start():
    print(f"Dear {user_name},\nYou need to find a way to leave this building.\nThere are 2 doors in front of you.\nDo you open the door on the left or the door on the right?")
    choose_door()


def choose_door():
    door_choice = input("> ")
    
    if "left" in door_choice:
        dark_room()
    elif "right" in door_choice:
        light_room()
    else:
        print("Type either left or right.")
        choose_door()


def dark_room():
    if 'lamp' in hand:
        dark_room2()
    else:
        dark_room1()

def dark_room1():
    print(f"Dear {user_name},\nYou are now in the dark_room.\nAny number of hidden dangers could be here.")
    dark_action = input("> ")
    
    if "leave" in dark_action:
        start()
    else:
        die("The only way to survive is to leave. You have been attacked by the darkness - death ensues.")


dark_room_list = ['monster', 'key']


def dark_room2():
    print(f"Dear {user_name},\nIn this room you see:\n",dark_room_list)
    
    if 'sword' in hand:
        sword_dark_room()
    else:
        no_sword_dark_room()


def sword_dark_room():
    sword_dark_action = input("> ")
    
    if ("fight" in sword_dark_action) or ("kill" in sword_dark_action):
        pprint("Well done, the monster is dead.")
        monster_dead()
    elif "leave" in sword_dark_action:
        start()
    else:
        die("The only way to survive is to kill the monster. As you did not, the monster kills you.")


def no_sword_dark_room():
    no_sword_dark_action = input("> ")
    
    if "leave" in no_sword_dark_action:
        start()
    elif "fight" or "kill" in no_sword_dark_action:
        die("You need a sword to fight the monster. It kills you.")
    else:
        die("The only way to survive is to leave. As you did not, the monster kills you.")


def monster_dead():
    dark_room_list.remove('monster')


def extract_thing(user_command, action):
    user_command.find(action)
    pos = len(action)
    thing = user_command[pos:]
    return thing


#user_command = input("> ")

#if "hold " in user_command:
#    hold_thing = extract_thing(user_command, "hold ")
#    hand.append(hold_thing)
#    print("You are now holding:")
#    print(hand)

#if "drop " in user_command:
#    drop_thing = extract_thing(user_command, "drop ")
#    hand.remove(drop_thing)
#    print("You are now holding:")
#    print(hand)


def die(why):
    print(why, "You lost; try again?")
    exit_or_again()


def exit_or_again():
    again = input("Type yes or no > ")
    
    if "yes" in again:
        start()
    elif "no" in again:
        exit(0)
    else:
        exit_or_again()


start()
