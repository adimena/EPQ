def apple():
    print("I AM APPLES!")

# this is just a variable
tangerine = "Living reflection of a dream"
