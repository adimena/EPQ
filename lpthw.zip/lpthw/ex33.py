i = 0
numbers = [] # new list that items will soon be added to

print("Make your very own list!\nSpecify the parameters of the list by answering these questions.")

print("What will the highest number of the list be?")
limit = int(input("> ")) + 1
print("What is the interval between each number in the list?")
interval = int(input("> "))

def fill_list(i):
    print("Building list...")
    while i < limit:
        numbers.append(i) # add i to the "numbers" list
        
        i += interval
        print("Numbers now: ", numbers) # prints the "numbers" list
        print(f"(i is now {i})") # prints the new value of i
        print("------")


fill_list(i)
print("Here are the numbers in order in your list: ")

for n in numbers:
    print(n) # prints each item of the "numbers" list

print("All done!")
