from sys import argv

script, input_file = argv

def print_all(f): # what is f? I think it specifies what file
    print(f.read()) # print what is read in the file
    
def rewind(f):
    f.seek(0) # seek moves the position of the File Handle (like a cursor) - the number is bytes

def print_a_line(line_count, f):
    print(line_count, f.readline()) # print the line specified in the bracket?

current_file = open(input_file)

print("First let's print the whole file:\n")

print_all(current_file)

print("Now let's rewind, kind of like a tape.")

rewind(current_file)

print("Let's print three lines:\n")

current_line = 1
print_a_line(current_line, current_file)

current_line += 1 # go down one line so current line is line 2
print_a_line(current_line, current_file)

current_line += 1
print_a_line(current_line, current_file)
