print("I will now count my chickens:") # prints the text in the brackets

print("Hens", 25 + 30 / 6) # prints "hens" then works out the question
print("Rosters", 100 - 25 * 3 % 4) # see above

print("Now I will count the eggs:") # see line 1

print(3 + 2 + 1 - 5 + 4 % 2 - 1 / 4 + 6) # prints the answer

print("Is it true that 3 + 2 < 5 - 7?")

print(3 + 2 < 5 - 7) # states whether this statement is "true" if the answer to the left is smaller than the answer to the right, or "false" if not

print("What is 3 + 2?", 3 + 2)
print("What is 5 - 7?", 5 - 7)

print("Oh, that's why it's False.")

print("How about some more.")

print("Is it greater?", 5 > -2)
print("Is it greater or equal?", 5 >= -2)
print("Is it less or equal?", 5 <= -2)
