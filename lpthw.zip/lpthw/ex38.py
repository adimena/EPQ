ten_things = "Apples Oranges Crows Telephone Light Sugar"

print("Wait, there are not 10 things in that list. Let's fix that.")

stuff = ten_things.split(' ') # makes list where space means new item
more_stuff = ["Day", "Night", "Song", "Frisbee",
              "Corn", "Banana", "Girl", "Boy"]

while len(stuff) != 10:
    next_one = more_stuff.pop() # takes last item in list
    # more_stuff.pop() [call pop on more_stuff] = pop(more_stuff) [call pop with argument more_stuff]
    print("Adding: ", next_one)
    stuff.append(next_one)
    print(f"There are {len(stuff)} items now.")

print("There we go: ", stuff)

print("Let's do some things with stuff.")

print(stuff[1]) # print 2nd item
print(stuff[-1]) # prints last item of stuff
print(stuff.pop()) # takes last item of stuff
print(stuff)
print(' '.join(stuff)) # prints all items with space between
print('#'.join(stuff[3:5])) # prints only items 3-4 (4th and 5th) with # between
